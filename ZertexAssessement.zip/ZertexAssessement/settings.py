DATABASES = {
'default':{
    'ENGINE': 'django.db.backends.postgresql_psycopg2',
    'NAME': 'login_db',
    'USER':'root',
    'PASSWORD':'your_password',
    'HOST':'localhost',
    'PORT':'3306',
    
}
}
