from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import User

@csrf_exempt
def login_api(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')
        user = User.objects.filter(username=username, password=password).first()
        if user:
            return JsonResponse({'message': 'Login Successful'},status=200)
        else:
            return JsonResponse({'message': 'Login Failed'},status=400)
    else:
        return JsonResponse({'message': 'Invalid Request'})