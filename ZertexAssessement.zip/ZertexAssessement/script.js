document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const responseMessage = document.getElementById('responseMessage');
    try{
        const response= await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({username, password})
        });
        const data = await response.json();
        responseMessage.textContent = data.message;
        responseMessage.style.color = response.ok ? 'green' : 'red';
    } catch(err) {
        responseMessage.textContent = err.message;
        responseMessage.style.color = 'red';
    }
});